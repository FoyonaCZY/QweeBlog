import React from 'react';
import { Container, CssBaseline, Box } from '@mui/material';
import AppAppBar from './components/AppBarHomePage';
import MainContentHomePage from './components/MainContentHomePage.js';
import config from '../data/siteconfig';

function HomePage() {
    return (
        <>
            <Box sx={{
                backgroundImage: `url(${config.backgroundImage})`,
                backgroundSize: 'cover',
                backgroundRepeat: 'no-repeat',
                backgroundPosition: 'center',
                backgroundAttachment: 'fixed',
                position: 'absolute',
                width: '100vw',
                height: '100vh',
            }}
            />
            <Box sx={
                {
                    display: 'flex',
                    flexDirection: 'column',
                    gap: 4,
                    position: 'absolute',
                    width: '100vw',
                    height: '100vh',
                }
            }>
                <CssBaseline enableColorScheme />
                <Container
                    maxWidth="lg"
                    component="main"
                    sx={{ display: 'flex', flexDirection: 'column', my: 16, gap: 4 }}
                >
                    <AppAppBar />
                    <MainContentHomePage />
                </Container>
            </Box></>
    );
}

export default HomePage;