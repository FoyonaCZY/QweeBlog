import React from "react";
import { Box, Typography} from "@mui/material";

export default function PostDetail(ID, title, content, avatar, author, authoravatar, category, created_at, updated_at) {
    return (
        <Box key={ID}
            sx={{
                borderRadius: '8px',
                height: '500px',
                boxShadow: 3,
                overflow: 'hidden',
                display: 'flex',
                flexDirection: 'column',
                backgroundColor: 'background.paper',
            }}
        >
            <Box
                sx={{
                    flex: '2',
                    backgroundImage: `url(${avatar})`,
                    backgroundSize: 'cover',
                    backgroundPosition: 'center',
                    alignItems: 'center',
                    display: 'flex',
                    justifyContent: 'center',
                }}
            >
                <Typography variant="h5" gutterBottom sx={
                    {
                        fontFamily: 'Microsoft YaHei',
                        fontSize: '2.0rem',
                        color: 'white',
                        textShadow: '2px 2px 4px rgba(0, 0, 0, 0.3)',  // 设置阴影
                    }
                }>
                    {title}
                </Typography>
            </Box>

            <Box
                sx={{
                    flex:'1',
                    padding: 2,
                }}
            >
                <Typography variant="body2" color="text.secondary" sx = {
                    {
                        display: 'flex',
                        gap: 1,
                        alignItems: 'center',
                        fontFamily: 'Microsoft YaHei',
                        fontSize: '0.8rem',
                    }
                }>
                    {content}
                </Typography>
            </Box>
        </Box>
    );
}