const config = {
    apiDomain:'http://localhost:5212/',
    siteTitle: 'CZY\'s Blog',
    siteDescription: 'Don\'t Know What to Write Here Yet',
    backgroundImage: 'https://z1.ax1x.com/2023/09/20/pPImlRO.jpg',
}
export default config;